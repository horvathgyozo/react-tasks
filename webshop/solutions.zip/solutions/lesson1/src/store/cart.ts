import { create } from 'zustand'
import type { Product } from '../types'

interface CartItem {
  productId: string
  qty: number
}

interface CartState {
  cart: CartItem[]
  add: (productId: string) => void
  dec: (productId: string) => void
  remove: (productId: string) => void
  clear: () => void
  totalQty: () => number
  totalPrice: (products: Product[]) => number
}

export const useCartStore = create<CartState>((set, get) => ({
  cart: [],

  add: (productId) =>
    set((state) => {
      const existing = state.cart.find((item) => item.productId === productId)
      if (existing) {
        return {
          cart: state.cart.map((item) =>
            item.productId === productId ? { ...item, qty: item.qty + 1 } : item,
          ),
        }
      }
      return { cart: [...state.cart, { productId, qty: 1 }] }
    }),

  dec: (productId) =>
    set((state) => {
      const item = state.cart.find((i) => i.productId === productId)
      if (!item) return state
      if (item.qty <= 1) {
        return { cart: state.cart.filter((i) => i.productId !== productId) }
      }
      return {
        cart: state.cart.map((i) =>
          i.productId === productId ? { ...i, qty: i.qty - 1 } : i,
        ),
      }
    }),

  remove: (productId) =>
    set((state) => ({
      cart: state.cart.filter((i) => i.productId !== productId),
    })),

  clear: () => set({ cart: [] }),

  totalQty: () => get().cart.reduce((sum, item) => sum + item.qty, 0),

  totalPrice: (products) =>
    get().cart.reduce((sum, item) => {
      const product = products.find((p) => p.id === item.productId)
      return sum + (product?.priceHuf ?? 0) * item.qty
    }, 0),
}))
