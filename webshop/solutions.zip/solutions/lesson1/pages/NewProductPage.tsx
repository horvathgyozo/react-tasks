import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ProductCard } from '../components/ProductCard'
import { useProductsStore } from '../../../client/src/store/products'
import type { Product } from '../../../client/src/types'

const placeholderImageUrl =
  'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80'

interface FormState {
  name: string
  priceHuf: string
  imageUrl: string
  description: string
}

interface FormErrors {
  name?: string
  priceHuf?: string
  description?: string
}

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {}
  if (!form.name.trim()) errors.name = 'Name is required.'
  const price = Number(form.priceHuf)
  if (!form.priceHuf || isNaN(price) || price <= 0)
    errors.priceHuf = 'Price must be a positive number.'
  if (form.description.trim().length < 10)
    errors.description = 'Description must be at least 10 characters.'
  return errors
}

export function NewProductPage() {
  const navigate = useNavigate()
  const { addProduct } = useProductsStore()

  const [form, setForm] = useState<FormState>({
    name: '',
    priceHuf: '',
    imageUrl: '',
    description: '',
  })
  const [errors, setErrors] = useState<FormErrors>({})

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) {
    setForm({ ...form, [e.target.name]: e.target.value })
    setErrors({ ...errors, [e.target.name]: undefined })
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const errs = validate(form)
    if (Object.keys(errs).length > 0) {
      setErrors(errs)
      return
    }

    const newProduct: Product = {
      id: `local-${Date.now()}`,
      name: form.name.trim(),
      priceHuf: Number(form.priceHuf),
      imageUrl: form.imageUrl.trim() || placeholderImageUrl,
      description: form.description.trim(),
    }
    addProduct(newProduct)
    navigate('/')
  }

  const previewProduct: Product = {
    id: 'preview',
    name: form.name || 'New coffee',
    priceHuf: Number(form.priceHuf) || 0,
    imageUrl: form.imageUrl || placeholderImageUrl,
    description: form.description || 'Short coffee description…',
  }

  return (
    <div className="space-y-4">
      <div className="breadcrumbs text-sm">
        <ul>
          <li>
            <Link to="/">Products</Link>
          </li>
          <li>New product</li>
        </ul>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <ProductCard product={previewProduct} showActions={false} />
        </div>

        <div className="card bg-base-100 shadow lg:col-span-3">
          <div className="card-body">
            <div className="flex items-center justify-between gap-3">
              <h1 className="card-title text-2xl">New product</h1>
              <span className="badge badge-primary badge-outline">Coffee</span>
            </div>

            <div className="divider my-2" />

            <form
              className="grid grid-cols-1 gap-4 sm:grid-cols-2"
              onSubmit={handleSubmit}
            >
              <label className="form-control">
                <div className="label">
                  <span className="label-text">Name</span>
                </div>
                <input
                  className="input input-bordered w-full"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                />
                {errors.name && (
                  <div className="label">
                    <span className="label-text-alt text-error">{errors.name}</span>
                  </div>
                )}
              </label>

              <label className="form-control">
                <div className="label">
                  <span className="label-text">Price</span>
                  <span className="label-text-alt opacity-70">HUF</span>
                </div>
                <input
                  className="input input-bordered w-full"
                  inputMode="numeric"
                  name="priceHuf"
                  value={form.priceHuf}
                  onChange={handleChange}
                />
                {errors.priceHuf && (
                  <div className="label">
                    <span className="label-text-alt text-error">{errors.priceHuf}</span>
                  </div>
                )}
              </label>

              <label className="form-control sm:col-span-2">
                <div className="label">
                  <span className="label-text">Image URL</span>
                  <span className="label-text-alt opacity-70">
                    empty = placeholder
                  </span>
                </div>
                <input
                  className="input input-bordered w-full"
                  placeholder={placeholderImageUrl}
                  name="imageUrl"
                  value={form.imageUrl}
                  onChange={handleChange}
                />
              </label>

              <label className="form-control sm:col-span-2">
                <div className="label">
                  <span className="label-text">Description</span>
                </div>
                <textarea
                  className="textarea textarea-bordered w-full min-h-32"
                  name="description"
                  value={form.description}
                  onChange={handleChange}
                />
                {errors.description && (
                  <div className="label">
                    <span className="label-text-alt text-error">
                      {errors.description}
                    </span>
                  </div>
                )}
              </label>

              <div className="sm:col-span-2 flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  className="btn"
                  onClick={() => {
                    setForm({ name: '', priceHuf: '', imageUrl: '', description: '' })
                    setErrors({})
                  }}
                >
                  Reset
                </button>
                <button type="submit" className="btn btn-primary">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
