import { Link } from 'react-router-dom'
import { useCartStore } from '../store/cart'
import { useProductsQuery } from '../lib/queries'

export function CartPage() {
  const { data: products = [] } = useProductsQuery()
  const { cart, remove, clear, totalQty, totalPrice } = useCartStore()

  const enriched = cart.map((item) => ({
    ...item,
    product: products.find((p) => p.id === item.productId),
  }))

  return (
    <div className="space-y-4">
      <div className="rounded-box bg-base-100 p-6 shadow">
        <div className="flex items-center justify-between gap-3">
          <h1 className="text-2xl font-bold">
            Cart ({totalQty()} {totalQty() === 1 ? 'item' : 'items'})
          </h1>
          <button className="btn btn-ghost btn-sm" onClick={clear}>
            Clear all
          </button>
        </div>
      </div>

      {cart.length === 0 ? (
        <div className="rounded-box bg-base-100 p-6 shadow text-center opacity-70">
          Your cart is empty.{' '}
          <Link to="/" className="link link-primary">
            Shop now
          </Link>
        </div>
      ) : (
        <div className="rounded-box bg-base-100 p-6 shadow space-y-3">
          {enriched.map(({ productId, qty, product }) =>
            product ? (
              <div key={productId} className="flex items-center gap-4">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="h-14 w-14 rounded object-cover"
                />
                <div className="flex-1">
                  <div className="font-semibold">{product.name}</div>
                  <div className="text-sm opacity-70">
                    {qty} × {product.priceHuf} HUF
                  </div>
                </div>
                <div className="font-semibold">
                  {(qty * product.priceHuf).toLocaleString('hu-HU')} HUF
                </div>
                <button
                  className="btn btn-xs btn-ghost text-error"
                  onClick={() => remove(productId)}
                >
                  Remove
                </button>
              </div>
            ) : null,
          )}

          <div className="divider" />

          <div className="flex justify-end text-lg font-bold">
            Total: {totalPrice(products).toLocaleString('hu-HU')} HUF
          </div>
        </div>
      )}
    </div>
  )
}
