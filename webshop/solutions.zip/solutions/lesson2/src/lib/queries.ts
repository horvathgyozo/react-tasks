import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from './api'
import type { Product } from '../types'

// ─── Product queries ─────────────────────────────────────────────────────────

export function useProductsQuery() {
  return useQuery({
    queryKey: ['products'],
    queryFn: () =>
      api.get<{ items: Product[] }>('/products').then((r) => r.items),
  })
}

export function useProductQuery(id: string) {
  return useQuery({
    queryKey: ['products', id],
    queryFn: () => api.get<Product>(`/products/${id}`),
    enabled: !!id,
  })
}

// ─── Product mutations ───────────────────────────────────────────────────────

type CreateProductInput = Omit<Product, 'id'> & { id?: string }

export function useCreateProductMutation(token: string | null) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: CreateProductInput) =>
      api.post<Product>('/products', body, token ?? undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] })
    },
  })
}

// ─── Auth mutations ──────────────────────────────────────────────────────────

interface AuthResponse {
  token: string
  user: { email: string }
}

export function useLoginMutation() {
  return useMutation({
    mutationFn: (body: { email: string; password: string }) =>
      api.post<AuthResponse>('/auth/login', body),
  })
}

export function useRegisterMutation() {
  return useMutation({
    mutationFn: (body: { email: string; password: string }) =>
      api.post<AuthResponse>('/auth/register', body),
  })
}
