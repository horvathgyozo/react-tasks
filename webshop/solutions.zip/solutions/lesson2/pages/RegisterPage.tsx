import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useRegisterMutation } from '../lib/queries'
import { useAuthStore } from '../store/auth'

export function RegisterPage() {
  const navigate = useNavigate()
  const setToken = useAuthStore((s) => s.setToken)
  const { mutate: register, isPending, error } = useRegisterMutation()

  const [form, setForm] = useState({ email: '', password: '' })

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    register(form, {
      onSuccess: ({ token }) => {
        setToken(token)
        navigate('/')
      },
    })
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        <div className="card bg-base-100 shadow lg:col-span-2">
          <figure className="aspect-[4/3] overflow-hidden bg-base-200">
            <img
              src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80"
              alt="Coffee"
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </figure>
          <div className="card-body">
            <h2 className="card-title text-lg">Create an account</h2>
            <p className="text-sm opacity-70">
              You'll be logged in immediately after registration.
            </p>
          </div>
        </div>

        <div className="card bg-base-100 shadow lg:col-span-3">
          <div className="card-body">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl font-bold">Register</h1>
                <p className="mt-1 text-sm opacity-70">
                  Already have an account?{' '}
                  <Link to="/login" className="link link-primary">
                    Login
                  </Link>
                </p>
              </div>
              <span className="badge badge-primary badge-outline">Coffee</span>
            </div>

            <div className="divider my-2" />

            {error && (
              <div className="alert alert-error text-sm">{error.message}</div>
            )}

            <form
              className="grid grid-cols-1 gap-4 sm:grid-cols-2"
              onSubmit={handleSubmit}
            >
              <label className="form-control sm:col-span-2">
                <div className="label">
                  <span className="label-text">Email</span>
                </div>
                <input
                  className="input input-bordered w-full"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={form.email}
                  onChange={handleChange}
                />
              </label>

              <label className="form-control sm:col-span-2">
                <div className="label">
                  <span className="label-text">Password</span>
                </div>
                <input
                  className="input input-bordered w-full"
                  type="password"
                  name="password"
                  autoComplete="new-password"
                  required
                  value={form.password}
                  onChange={handleChange}
                />
              </label>

              <div className="sm:col-span-2 flex items-center justify-end gap-2 pt-2">
                <Link to="/" className="btn">
                  Cancel
                </Link>
                <button
                  className="btn btn-primary"
                  type="submit"
                  disabled={isPending}
                >
                  {isPending && (
                    <span className="loading loading-spinner loading-sm" />
                  )}
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
