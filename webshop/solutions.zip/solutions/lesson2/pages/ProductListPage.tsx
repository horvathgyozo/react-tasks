import { ProductCard } from '../../../client/src/components/ProductCard'
import { useProductsQuery } from '../lib/queries'

export function ProductListPage() {
  const { data: products, isPending, isError } = useProductsQuery()

  if (isPending) {
    return (
      <div className="flex justify-center py-16">
        <span className="loading loading-spinner loading-lg" />
      </div>
    )
  }

  if (isError) {
    return (
      <div className="rounded-box bg-error/10 p-6 text-error">
        Failed to load products. Is the API running?
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="breadcrumbs text-sm">
        <ul>
          <li>Products</li>
        </ul>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  )
}
